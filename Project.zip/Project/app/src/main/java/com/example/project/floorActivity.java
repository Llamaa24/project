package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class floorActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> floorNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_floor);

        listView = findViewById(R.id.list_view);
        floorNames = new ArrayList<>();

        String buildingName = getIntent().getStringExtra("buildingName");
        Building building = getBuildingByName(buildingName);

        if (building != null) {
            for (Floor floor : building.getFloors()) {
                floorNames.add("Floor " + floor.getNumber());
            }
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, floorNames);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            int floorNumber = building.getFloors().get(position).getNumber();
            Intent intent = new Intent(floorActivity.this, classActivity.class);
            intent.putExtra("buildingName", buildingName);
            intent.putExtra("floorNumber", floorNumber);
            startActivity(intent);
        });
    }

    private Building getBuildingByName(String name) {
        for (Building building : DataInitializer.initializeData()) {
            if (building.getName().equals(name)) {
                return building;
            }
        }
        return null;
    }
}

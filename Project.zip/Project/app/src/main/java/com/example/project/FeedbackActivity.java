package com.example.project;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FeedbackActivity extends AppCompatActivity {
    private EditText commentEditText;
    private Button addCommentButton;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        commentEditText = findViewById(R.id.comment_edit_text);
        addCommentButton = findViewById(R.id.add_comment_button);

        // Initialize Firebase Database reference
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("feedback");

        addCommentButton.setOnClickListener(v -> {
            String className = getIntent().getStringExtra("className");
            String comment = commentEditText.getText().toString();

            if (!comment.isEmpty()) {
                saveCommentToDatabase(className, comment);
                Toast.makeText(FeedbackActivity.this, "Comment added successfully", Toast.LENGTH_SHORT).show();
                finish(); // Go back to the previous screen
            } else {
                Toast.makeText(FeedbackActivity.this, "Comment cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveCommentToDatabase(String className, String comment) {
        // Create a unique key for each comment
        String key = databaseReference.push().getKey();

        // Save the comment in the "feedback" node in Firebase
        if (key != null) {
            databaseReference.child(className).child(key).setValue(comment);
        }
    }
}
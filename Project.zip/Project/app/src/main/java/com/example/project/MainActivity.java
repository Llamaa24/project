package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseReference database;
    private ListView listView;
    private SearchView searchView;
    private ArrayAdapter<String> adapter;
    private List<Building> buildings;
    private List<String> searchResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        database = firebaseDatabase.getReference();

        // Initialize views
        listView = findViewById(R.id.list_view);
        searchView = findViewById(R.id.search_view);

        // Initialize data
        buildings = DataInitializer.initializeData();
        searchResults = new ArrayList<>();

        // Write all data to Firebase
        for (Building building : buildings) {
            database.child("buildings").child(building.getName()).setValue(building);
        }

        // Set up adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, searchResults);
        listView.setAdapter(adapter);

        // Set up search view
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchResults.clear();
                for (Building building : buildings) {
                    if (building.getName().toLowerCase().contains(newText.toLowerCase())) {
                        searchResults.add(building.getName());
                    }
                    for (Floor floor : building.getFloors()) {
                        for (Section section : floor.getSections()) {
                            for (Classroom classroom : section.getClassrooms()) {
                                if (classroom.getName().toLowerCase().contains(newText.toLowerCase())) {
                                    searchResults.add(classroom.getName() + " (" + building.getName() + ")");
                                }
                            }
                        }
                    }
                }
                adapter.notifyDataSetChanged();
                return false;
            }
        });

        // Set up list view item click listener
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = searchResults.get(position);
            if (selectedItem.contains("(")) {
                // It's a class/lab
                String[] parts = selectedItem.split(" \\(");
                String className = parts[0];
                String buildingName = parts[1].replace(")", "");

                Intent intent = new Intent(MainActivity.this, ClassDetailActivity.class);
                intent.putExtra("buildingName", buildingName);
                intent.putExtra("className", className);
                startActivity(intent);
            } else {
                // It's a building
                Intent intent = new Intent(MainActivity.this, floorActivity.class);
                intent.putExtra("buildingName", selectedItem);
                startActivity(intent);
            }
        });
    }
}